﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Server.RunServer();
            Random random = new Random();
            for (int i = 0; i < 100; i++)
            {
                listBox1.Items.Add(random.Next(-101, 100));
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Fonksiyonlar2.ListBoxModAl(radioButton3.Checked ? 3 : radioButton5.Checked ? 5 : radioButton7.Checked ? 7 : 1, listBox1, listBox2, radioButton1.Checked, radioButton2.Checked);
        }
    }
}
