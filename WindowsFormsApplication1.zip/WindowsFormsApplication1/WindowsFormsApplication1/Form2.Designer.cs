﻿namespace WindowsFormsApplication1
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.button2 = new System.Windows.Forms.Button();
            this.lst3eBolunen = new System.Windows.Forms.ListBox();
            this.lst3ve5eBolunen = new System.Windows.Forms.ListBox();
            this.lst5eBolunen = new System.Windows.Forms.ListBox();
            this.lst3ve7yeBolunen = new System.Windows.Forms.ListBox();
            this.lst7yeBolunen = new System.Windows.Forms.ListBox();
            this.lst5ve7yeBolunen = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lstDiger = new System.Windows.Forms.ListBox();
            this.label7 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(150, 23);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "Aktar";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(12, 52);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(120, 303);
            this.listBox1.TabIndex = 1;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(30, 23);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 2;
            this.button2.Text = "Oluştur";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // lst3eBolunen
            // 
            this.lst3eBolunen.FormattingEnabled = true;
            this.lst3eBolunen.Location = new System.Drawing.Point(165, 81);
            this.lst3eBolunen.Name = "lst3eBolunen";
            this.lst3eBolunen.Size = new System.Drawing.Size(120, 95);
            this.lst3eBolunen.TabIndex = 3;
            // 
            // lst3ve5eBolunen
            // 
            this.lst3ve5eBolunen.FormattingEnabled = true;
            this.lst3ve5eBolunen.Location = new System.Drawing.Point(165, 215);
            this.lst3ve5eBolunen.Name = "lst3ve5eBolunen";
            this.lst3ve5eBolunen.Size = new System.Drawing.Size(120, 95);
            this.lst3ve5eBolunen.TabIndex = 3;
            // 
            // lst5eBolunen
            // 
            this.lst5eBolunen.FormattingEnabled = true;
            this.lst5eBolunen.Location = new System.Drawing.Point(311, 81);
            this.lst5eBolunen.Name = "lst5eBolunen";
            this.lst5eBolunen.Size = new System.Drawing.Size(120, 95);
            this.lst5eBolunen.TabIndex = 3;
            // 
            // lst3ve7yeBolunen
            // 
            this.lst3ve7yeBolunen.FormattingEnabled = true;
            this.lst3ve7yeBolunen.Location = new System.Drawing.Point(311, 215);
            this.lst3ve7yeBolunen.Name = "lst3ve7yeBolunen";
            this.lst3ve7yeBolunen.Size = new System.Drawing.Size(120, 95);
            this.lst3ve7yeBolunen.TabIndex = 3;
            // 
            // lst7yeBolunen
            // 
            this.lst7yeBolunen.FormattingEnabled = true;
            this.lst7yeBolunen.Location = new System.Drawing.Point(462, 81);
            this.lst7yeBolunen.Name = "lst7yeBolunen";
            this.lst7yeBolunen.Size = new System.Drawing.Size(120, 95);
            this.lst7yeBolunen.TabIndex = 3;
            // 
            // lst5ve7yeBolunen
            // 
            this.lst5ve7yeBolunen.FormattingEnabled = true;
            this.lst5ve7yeBolunen.Location = new System.Drawing.Point(462, 215);
            this.lst5ve7yeBolunen.Name = "lst5ve7yeBolunen";
            this.lst5ve7yeBolunen.Size = new System.Drawing.Size(120, 95);
            this.lst5ve7yeBolunen.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(165, 62);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "3e bolunen";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(165, 199);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "3 ve 5e bolunen";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(308, 199);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(89, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "3 ve 7ye bolunen";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(459, 199);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(89, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "5 ve 7ye bolunen";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(459, 65);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "7ye bolunen";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(308, 65);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(60, 13);
            this.label6.TabIndex = 4;
            this.label6.Text = "5e bolunen";
            // 
            // lstDiger
            // 
            this.lstDiger.FormattingEnabled = true;
            this.lstDiger.Location = new System.Drawing.Point(620, 215);
            this.lstDiger.Name = "lstDiger";
            this.lstDiger.Size = new System.Drawing.Size(120, 95);
            this.lstDiger.TabIndex = 5;
            this.lstDiger.SelectedIndexChanged += new System.EventHandler(this.listBox2_SelectedIndexChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(620, 198);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(32, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "Diğer";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(748, 367);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.lstDiger);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lst5ve7yeBolunen);
            this.Controls.Add(this.lst7yeBolunen);
            this.Controls.Add(this.lst3ve7yeBolunen);
            this.Controls.Add(this.lst5eBolunen);
            this.Controls.Add(this.lst3ve5eBolunen);
            this.Controls.Add(this.lst3eBolunen);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.button1);
            this.Name = "Form2";
            this.Text = "Form2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ListBox lst3eBolunen;
        private System.Windows.Forms.ListBox lst3ve5eBolunen;
        private System.Windows.Forms.ListBox lst5eBolunen;
        private System.Windows.Forms.ListBox lst3ve7yeBolunen;
        private System.Windows.Forms.ListBox lst7yeBolunen;
        private System.Windows.Forms.ListBox lst5ve7yeBolunen;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ListBox lstDiger;
        private System.Windows.Forms.Label label7;
    }
}