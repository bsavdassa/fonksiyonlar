﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace WindowsFormsApplication1
{
    public partial class Form2 : Form 
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Random random = new Random();
            for (int i = 0; i < 100; i++)
            {
                listBox1.Items.Add(random.Next(1, 300));
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Fonksiyonlar.ListBoxModAl(3, listBox1, lst3eBolunen);
            Fonksiyonlar.ListBoxModAl(5, listBox1, lst5eBolunen);
            Fonksiyonlar.ListBoxModAl(7, listBox1, lst7yeBolunen);
            Fonksiyonlar.ListBoxModAl(3, 5, listBox1, lst3ve5eBolunen);
            Fonksiyonlar.ListBoxModAl(3, 7, listBox1, lst3ve7yeBolunen);
            Fonksiyonlar.ListBoxModAl(5, 7, listBox1, lst5ve7yeBolunen);
            Fonksiyonlar.ListBoxModAlDigerNN(listBox1, lstDiger, 3, 5, 7);
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
