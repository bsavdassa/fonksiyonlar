﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    class Fonksiyonlar2
    {
        public static void ListBoxModAl(int bolenSayi1, ListBox lstKontrolEdilenListe, ListBox lstEklenecekListe, bool sadecePozitif = false, bool sadeceNegatif = false)
        {
            lstEklenecekListe.Items.Clear();
            foreach (int index in lstKontrolEdilenListe.Items)
            {
                if (index % bolenSayi1 == 0 && (sadeceNegatif ? index <0 : true) && (sadecePozitif ? index>0 : true))
                {
                    lstEklenecekListe.Items.Add(index.ToString());
                }
            }
        }
    }
}
