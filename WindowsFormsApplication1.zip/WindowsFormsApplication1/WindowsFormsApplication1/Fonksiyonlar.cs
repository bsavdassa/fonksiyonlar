﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace WindowsFormsApplication1
{
    class Fonksiyonlar
    {
        public static void ListBoxModAl(int bolenSayi1, ListBox lstKontrolEdilenListe, ListBox lstEklenecekListe)
        {
            foreach (int index in lstKontrolEdilenListe.Items)
            {
                if (index%bolenSayi1 == 0)
                {
                    lstEklenecekListe.Items.Add(index.ToString());
                }
            }
        }
        public static void ListBoxModAl(int bolenSayi1, int bolenSayi2, ListBox lstKontrolEdilenListe, ListBox lstEklenecekListe)
        {
            foreach (int index in lstKontrolEdilenListe.Items)
            {
                if ((index % bolenSayi1) + (index % bolenSayi2)  == 0)
                {
                    lstEklenecekListe.Items.Add(index.ToString());
                }
            }
        }
        public static void ListBoxModAlDigerNN(ListBox lstKontrolEdilenListe, ListBox lstEklenecekListe, params int[] bolenler)
        {
            
            foreach (int index in lstKontrolEdilenListe.Items)
            {
                bool modAlindi = false;
                foreach (var item in bolenler)
                {
                    if (modAlindi)
                    {
                        break;
                    }
                    modAlindi = index % item == 0;   
                }
                if (!modAlindi)
                {
                    lstEklenecekListe.Items.Add(index);
                }
                /*List<int> bolunmeSayisi = new List<int>() { };
                foreach (List<int> item in bolenler)
                {
                    List<int> ortakBolenler = new List<int>(){};
                    foreach (int item2 in item)
                    {
                        if (index % item2 == 0)
                        {
                            ortakBolenler.Add(index);
                        }
                    }
                    if (ortakBolenler.Count != item.Count)
                    {
                        bolunmeSayisi.Add(1);
                    }
                }
                if (bolunmeSayisi.Count==0)
                {
                    lstEklenecekListe.Items.Add(index.ToString());
                }*/
            }
        }
    }
}
